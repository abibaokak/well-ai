[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=0
HideExtractAnimation=1
UseLongFileName=1
InsideCompressed=1
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=
DisplayLicense=
FinishMessage=Well AI installed
TargetName=C:\Users\3B69~1\DOCUME~1\DEFAUL~1\WellAI\dist\WellAI-Setup.exe
FriendlyName=Well AI Setup
AppLaunched=cmd.exe /c install.bat
PostInstallCmd=<None>
AdminQuietInstCmd=
UserQuietInstCmd=
SourceFiles=SourceFiles
[Strings]
FILE0="WellAI.ps1"
FILE1="wellai.ico"
FILE2="install.ps1"
FILE3="install.bat"
FILE4="uninstall.ps1"
FILE5="config.default.json"
[SourceFiles]
SourceFiles0=C:\Users\3B69~1\AppData\Local\Temp\WELLAI~1
[SourceFiles0]
%FILE0%=
%FILE1%=
%FILE2%=
%FILE3%=
%FILE4%=
%FILE5%=
